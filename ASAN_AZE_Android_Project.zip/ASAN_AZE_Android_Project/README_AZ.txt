ASAN AZE — Android Studio layihəsi

Bu arxiv hazır APK deyil; Android Studio layihəsinin mənbə kodudur.

APK yaratmaq:
1. Arxivi kompüterdə çıxarın.
2. Android Studio-da "Open" seçin və ASAN_AZE_Android_Project qovluğunu açın.
3. Gradle sinxronizasiyasının bitməsini gözləyin (Android SDK 35 və uyğun Build Tools tələb olunur).
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. APK app/build/outputs/apk/debug/app-debug.apk qovluğunda yaranacaq.

Tətbiqin adı: ASAN AZE
Paket adı: com.asanaze.app
Oyun HTML faylı tətbiqin daxilindədir və internet bağlantısı tələb etmir.

Qeyd: Google Play-də yayımlamaq üçün ayrıca imzalanmış AAB, Play Console hesabı və Google-un cari tələblərinə uyğun yoxlamalar lazımdır.
